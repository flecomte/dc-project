--
-- function to alter the database so that the zdb.so library is loaded every time a session starts
--
DO LANGUAGE plpgsql $$
DECLARE
    session_preload_libraries text;
BEGIN
    session_preload_libraries = COALESCE (current_setting('session_preload_libraries'), '');
    IF (session_preload_libraries NOT LIKE '%zombodb.so%') THEN
        IF (session_preload_libraries = '') THEN
            session_preload_libraries = 'zombodb.so';
        ELSE
            session_preload_libraries = format('zombodb.so,%s', session_preload_libraries);
        END IF;

        EXECUTE format('ALTER DATABASE %I SET session_preload_libraries TO ''%s''', current_database(), session_preload_libraries);
    END IF;

END;
$$;

GRANT ALL ON SCHEMA zdb TO PUBLIC;--
-- misc functions
--
CREATE OR REPLACE FUNCTION version() RETURNS text PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_version';
CREATE OR REPLACE FUNCTION ctid(ctid_as_64bits bigint) RETURNS tid PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_ctid';

--
-- for making arbitrary requests to the ES cluster backing the specified index
--
CREATE OR REPLACE FUNCTION request(index regclass, endpoint text, method text DEFAULT 'GET', post_data text DEFAULT NULL) RETURNS text PARALLEL SAFE IMMUTABLE LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_request';

--
-- support functions
--
CREATE OR REPLACE FUNCTION index_name(index regclass) RETURNS text PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_index_name';
CREATE OR REPLACE FUNCTION index_url(index regclass) RETURNS text PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_index_url';
CREATE OR REPLACE FUNCTION index_type_name(index regclass) RETURNS text PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_index_type_name';
CREATE OR REPLACE FUNCTION index_mapping(index regclass) RETURNS json PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT (zdb.request(index, '_mapping?pretty')::json)->zdb.index_name(index);
$$;
CREATE OR REPLACE FUNCTION all_es_index_names() RETURNS SETOF text PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT zdb.index_name(oid::regclass) FROM pg_class WHERE relam = (SELECT oid FROM pg_am WHERE amname = 'zombodb');
$$;
--
-- ZomboDB's "zdbquery" type definition
--
CREATE TYPE pg_catalog.zdbquery;
CREATE OR REPLACE FUNCTION pg_catalog.zdbquery_in(cstring) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_in';
CREATE OR REPLACE FUNCTION pg_catalog.zdbquery_out(zdbquery) RETURNS cstring PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_out';
CREATE OR REPLACE FUNCTION pg_catalog.zdbquery_recv(internal) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_recv';
CREATE OR REPLACE FUNCTION pg_catalog.zdbquery_send(zdbquery) RETURNS bytea PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_send';
CREATE TYPE pg_catalog.zdbquery (
    INTERNALLENGTH = variable,
    INPUT = pg_catalog.zdbquery_in,
    OUTPUT = pg_catalog.zdbquery_out,
    RECEIVE = pg_catalog.zdbquery_recv,
    SEND = pg_catalog.zdbquery_send,
    ALIGNMENT = int4,
    STORAGE = extended
);

CREATE OR REPLACE FUNCTION zdbquery_from_text(text) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_from_text';
CREATE OR REPLACE FUNCTION zdbquery_from_json(json) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_from_text'; /* NB:  same C func as above */
CREATE OR REPLACE FUNCTION zdbquery_from_jsonb(jsonb) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_from_jsonb';
CREATE OR REPLACE FUNCTION zdbquery_to_json(zdbquery) RETURNS json PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_to_json';
CREATE OR REPLACE FUNCTION zdbquery_to_jsonb(zdbquery) RETURNS jsonb PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdbquery_to_jsonb';
CREATE CAST (text AS zdbquery) WITH FUNCTION zdbquery_from_text(text) AS IMPLICIT;
CREATE CAST (json AS zdbquery) WITH FUNCTION zdbquery_from_json(json) AS IMPLICIT;
CREATE CAST (jsonb AS zdbquery) WITH FUNCTION zdbquery_from_jsonb(jsonb) AS IMPLICIT;
CREATE CAST (zdbquery AS json) WITH FUNCTION zdbquery_to_json(zdbquery) AS IMPLICIT;
CREATE CAST (zdbquery AS jsonb) WITH FUNCTION zdbquery_to_jsonb(zdbquery) AS IMPLICIT;

--
-- query functions
--
CREATE OR REPLACE FUNCTION query(index regclass, query zdbquery) RETURNS SETOF tid IMMUTABLE STRICT ROWS 2500 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_query_srf';
CREATE OR REPLACE FUNCTION query_raw(index regclass, query zdbquery) RETURNS SETOF tid SET zdb.ignore_visibility = true IMMUTABLE STRICT ROWS 2500 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_query_srf';
CREATE OR REPLACE FUNCTION query_tids(index regclass, query zdbquery) RETURNS tid[] IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_query_tids';
CREATE OR REPLACE FUNCTION profile_query(index regclass, query zdbquery) RETURNS json IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_profile_query';

CREATE OR REPLACE FUNCTION zdb.set_query_property(property text, value text, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_set_query_property';

--
-- access method API functions and DDL
--
CREATE OR REPLACE FUNCTION amhandler(internal) RETURNS index_am_handler PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_amhandler';
CREATE OR REPLACE FUNCTION anyelement_cmpfunc(anyelement, zdbquery) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_anyelement_cmpfunc';
CREATE OR REPLACE FUNCTION anyelement_cmpfunc_array_should(anyelement, zdbquery[]) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_anyelement_cmpfunc_array_should';
CREATE OR REPLACE FUNCTION anyelement_cmpfunc_array_must(anyelement, zdbquery[]) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_anyelement_cmpfunc_array_must';
CREATE OR REPLACE FUNCTION anyelement_cmpfunc_array_not(anyelement, zdbquery[]) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_anyelement_cmpfunc_array_not';

CREATE OR REPLACE FUNCTION tid_cmpfunc(tid, zdbquery) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_tid_cmpfunc';
CREATE OR REPLACE FUNCTION tid_cmpfunc_array_should(tid, zdbquery[]) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_tid_cmpfunc_array_should';
CREATE OR REPLACE FUNCTION tid_cmpfunc_array_must(tid, zdbquery[]) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_tid_cmpfunc_array_must';
CREATE OR REPLACE FUNCTION tid_cmpfunc_array_not(tid, zdbquery[]) RETURNS bool PARALLEL SAFE IMMUTABLE STRICT COST 0.0001 LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_tid_cmpfunc_array_not';

CREATE OR REPLACE FUNCTION restrict(internal, oid, internal, integer) RETURNS float8 PARALLEL SAFE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_restrict';
CREATE OR REPLACE FUNCTION delete_trigger() RETURNS trigger LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_delete_trigger';
CREATE OR REPLACE FUNCTION update_trigger() RETURNS trigger LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_update_trigger';

CREATE ACCESS METHOD zombodb TYPE INDEX HANDLER zdb.amhandler;

CREATE OPERATOR pg_catalog.==> (
    PROCEDURE = zdb.anyelement_cmpfunc,
    RESTRICT = restrict,
    LEFTARG = anyelement,
    RIGHTARG = zdbquery
);
COMMENT ON OPERATOR pg_catalog.==>(anyelement, zdbquery) IS 'ZomboDB text search operator for Elasticsearch queries';

CREATE OPERATOR pg_catalog.==| (
    PROCEDURE = zdb.anyelement_cmpfunc_array_should,
    RESTRICT = restrict,
    LEFTARG = anyelement,
    RIGHTARG = zdbquery[]
);
COMMENT ON OPERATOR pg_catalog.==|(anyelement, zdbquery[]) IS 'ZomboDB array "should" text search operator for Elasticsearch queries';

CREATE OPERATOR pg_catalog.==& (
    PROCEDURE = zdb.anyelement_cmpfunc_array_must,
    RESTRICT = restrict,
    LEFTARG = anyelement,
    RIGHTARG = zdbquery[]
);
COMMENT ON OPERATOR pg_catalog.==&(anyelement, zdbquery[]) IS 'ZomboDB array "must" text search operator for Elasticsearch queries';

CREATE OPERATOR pg_catalog.==! (
    PROCEDURE = zdb.anyelement_cmpfunc_array_not,
    RESTRICT = restrict,
    LEFTARG = anyelement,
    RIGHTARG = zdbquery[]
);
COMMENT ON OPERATOR pg_catalog.==!(anyelement, zdbquery[]) IS 'ZomboDB array "not" text search operator for Elasticsearch queries';

CREATE OPERATOR CLASS anyelement_zdb_ops DEFAULT FOR TYPE anyelement USING zombodb AS
    OPERATOR 1 pg_catalog.==>(anyelement, zdbquery),
    OPERATOR 2 pg_catalog.==|(anyelement, zdbquery[]),
    OPERATOR 3 pg_catalog.==&(anyelement, zdbquery[]),
    OPERATOR 4 pg_catalog.==!(anyelement, zdbquery[]),
    STORAGE anyelement;

CREATE OPERATOR pg_catalog.==> (
    PROCEDURE = zdb.tid_cmpfunc,
    RESTRICT = restrict,
    LEFTARG = tid,
    RIGHTARG = zdbquery
);
COMMENT ON OPERATOR pg_catalog.==>(tid, zdbquery) IS 'ZomboDB text search operator for Elasticsearch queries';

CREATE OPERATOR pg_catalog.==| (
    PROCEDURE = zdb.tid_cmpfunc_array_should,
    RESTRICT = restrict,
    LEFTARG = tid,
    RIGHTARG = zdbquery[]
);
COMMENT ON OPERATOR pg_catalog.==|(tid, zdbquery[]) IS 'ZomboDB array "should" text search operator for Elasticsearch queries';

CREATE OPERATOR pg_catalog.==& (
    PROCEDURE = zdb.tid_cmpfunc_array_must,
    RESTRICT = restrict,
    LEFTARG = tid,
    RIGHTARG = zdbquery[]
);
COMMENT ON OPERATOR pg_catalog.==&(tid, zdbquery[]) IS 'ZomboDB array "must" text search operator for Elasticsearch queries';

CREATE OPERATOR pg_catalog.==! (
    PROCEDURE = zdb.tid_cmpfunc_array_not,
    RESTRICT = restrict,
    LEFTARG = tid,
    RIGHTARG = zdbquery[]
);
COMMENT ON OPERATOR pg_catalog.==!(tid, zdbquery[]) IS 'ZomboDB array "not" text search operator for Elasticsearch queries';

CREATE OPERATOR CLASS tid_zdb_ops DEFAULT FOR TYPE tid USING zombodb AS
    OPERATOR 1 pg_catalog.==>(tid, zdbquery),
    OPERATOR 2 pg_catalog.==|(tid, zdbquery[]),
    OPERATOR 3 pg_catalog.==&(tid, zdbquery[]),
    OPERATOR 4 pg_catalog.==!(tid, zdbquery[]),
    STORAGE tid;
CREATE OR REPLACE FUNCTION to_query_dsl(zdbquery) RETURNS json PARALLEL SAFE IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_to_query_dsl';
CREATE OR REPLACE FUNCTION to_queries_dsl(queries zdbquery[]) RETURNS json[] PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT array_agg(zdb.to_query_dsl(query)) FROM unnest(queries) query;
$$;

--
-- query composition functions
--
-- all of these should be created in the 'dsl' schema
--
CREATE SCHEMA dsl;
GRANT ALL ON SCHEMA dsl TO PUBLIC;

CREATE OR REPLACE FUNCTION dsl.offset_limit("offset" bigint, "limit" bigint, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT zdb.set_query_property('limit', "limit"::text, zdb.set_query_property('offset', "offset"::text, query));
$$;

CREATE OR REPLACE FUNCTION dsl.limit("limit" bigint, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT zdb.set_query_property('limit', "limit"::text, query);
$$;

CREATE OR REPLACE FUNCTION dsl.offset("offset" bigint, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT zdb.set_query_property('offset', "offset"::text, query);
$$;

CREATE TYPE dsl.es_sort_directions AS ENUM ('asc', 'desc');
CREATE TYPE dsl.es_sort_modes AS ENUM ('min', 'max', 'sum', 'avg', 'median');
CREATE TYPE dsl.es_sort_descriptor AS (
    field text,
    "order" dsl.es_sort_directions,
    mode dsl.es_sort_modes,
    nested_path text,
    nested_filter zdbquery
);

CREATE OR REPLACE FUNCTION dsl.sd(field text, "order" dsl.es_sort_directions, mode dsl.es_sort_modes DEFAULT NULL) RETURNS dsl.es_sort_descriptor PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT ($1, $2, $3, null, null)::dsl.es_sort_descriptor;
$$;

CREATE OR REPLACE FUNCTION dsl.sd_nested(field text, "order" dsl.es_sort_directions, nested_path text, nested_filter zdbquery DEFAULT NULL, mode dsl.es_sort_modes DEFAULT NULL) RETURNS dsl.es_sort_descriptor PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT ($1, $2, $5, $3, $4)::dsl.es_sort_descriptor;
$$;

CREATE OR REPLACE FUNCTION dsl.sort_many(query zdbquery, VARIADIC descriptors dsl.es_sort_descriptor[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    WITH sort_json AS (
        WITH descriptors AS (
            SELECT d.field, json_strip_nulls(json_build_object('order', d.order, 'mode', d.mode, 'nested_path', d.nested_path, 'nested_filter', d.nested_filter)) descriptor FROM unnest($2) d
        )
        SELECT json_agg(json_build_object(field, descriptor)) json FROM descriptors
    )
    SELECT zdb.set_query_property('sort_json', (SELECT json::jsonb::text FROM sort_json), $1);
$$;

CREATE OR REPLACE FUNCTION dsl.sort_direct(sort_json json, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT zdb.set_query_property('sort_json', $1::jsonb::text, $2);
$$;

CREATE OR REPLACE FUNCTION dsl.sort(sort_field text, sort_direction dsl.es_sort_directions, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT dsl.sort_many(query, dsl.sd(sort_field, sort_direction));
$$;

CREATE OR REPLACE FUNCTION dsl.min_score(min_score real, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT zdb.set_query_property('min_score', min_score::text, query);
$$;

CREATE OR REPLACE FUNCTION dsl.row_estimate(row_estimate real, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT zdb.set_query_property('row_estimate', row_estimate::text, query);
$$;

CREATE OR REPLACE FUNCTION dsl.match_all(boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('match_all', json_build_object('boost', boost)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.match_none() RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('match_none', '{}'::json))::zdbquery;
$$;

CREATE TYPE dsl.esqdsl_bool_part AS (query zdbquery);

CREATE OR REPLACE FUNCTION dsl.bool(VARIADIC queries dsl.esqdsl_bool_part[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_build_object('bool',
        (
            SELECT json_object_agg(type, query_array) FROM (
                SELECT type, json_agg(query) query_array FROM (
                    WITH queries AS (SELECT (unnest(queries)).query::json AS query)
                    SELECT 'should' AS type, json_array_elements(queries.query->'bool'->'should') AS query FROM queries WHERE queries.query->'bool'->'should' IS NOT NULL
                       UNION ALL
                    SELECT 'must', json_array_elements(queries.query->'bool'->'must') FROM queries WHERE queries.query->'bool'->'must' IS NOT NULL
                       UNION ALL
                    SELECT 'must_not', json_array_elements(queries.query->'bool'->'must_not') FROM queries WHERE queries.query->'bool'->'must_not' IS NOT NULL
                       UNION ALL
                    SELECT 'filter', json_array_elements(queries.query->'bool'->'filter') FROM queries WHERE queries.query->'bool'->'filter' IS NOT NULL
                ) x GROUP BY type ORDER BY type
            ) x
        )
    )::zdbquery;
$$;

CREATE OR REPLACE FUNCTION dsl.should(VARIADIC queries zdbquery[]) RETURNS dsl.esqdsl_bool_part PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT ROW(json_build_object('bool', json_build_object('should', queries)))::dsl.esqdsl_bool_part;
$$;
CREATE OR REPLACE FUNCTION dsl.must(VARIADIC queries zdbquery[]) RETURNS dsl.esqdsl_bool_part PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT ROW(json_build_object('bool', json_build_object('must', queries)))::dsl.esqdsl_bool_part;
$$;
CREATE OR REPLACE FUNCTION dsl.must_not(VARIADIC queries zdbquery[]) RETURNS dsl.esqdsl_bool_part PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT ROW(json_build_object('bool', json_build_object('must_not', queries)))::dsl.esqdsl_bool_part;
$$;
CREATE OR REPLACE FUNCTION dsl.filter(VARIADIC queries zdbquery[]) RETURNS dsl.esqdsl_bool_part PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT ROW(json_build_object('bool', json_build_object('filter', queries)))::dsl.esqdsl_bool_part;
$$;
CREATE OR REPLACE FUNCTION dsl.noteq(query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT dsl.bool(dsl.must_not(query));
$$;
CREATE OR REPLACE FUNCTION dsl.not(VARIADIC queries zdbquery[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT dsl.bool(dsl.must_not(VARIADIC queries));
$$;
CREATE OR REPLACE FUNCTION dsl.and(VARIADIC queries zdbquery[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT dsl.bool(dsl.must(VARIADIC queries));
$$;
CREATE OR REPLACE FUNCTION dsl.or(VARIADIC queries zdbquery[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT dsl.bool(dsl.should(VARIADIC queries));
$$;


CREATE TYPE dsl.esqdsl_term_text AS (value text, boost real);
CREATE TYPE dsl.esqdsl_term_numeric AS (value numeric, boost real);
CREATE OR REPLACE FUNCTION dsl.term(field text, value text, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('term', json_build_object(field, ROW(value, boost)::dsl.esqdsl_term_text)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.term(field text, value numeric, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('term', json_build_object(field, ROW(value, boost)::dsl.esqdsl_term_numeric)))::zdbquery;
$$;


CREATE OR REPLACE FUNCTION dsl.terms(field text, VARIADIC "values" text[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('terms', json_build_object(field, "values")))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.terms(field text, VARIADIC "values" numeric[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('terms', json_build_object(field, "values")))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.terms_array(field text, "values" anyarray) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('terms', json_build_object(field, "values")))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_terms_lookup AS (index text, type text, path text, id text);
CREATE OR REPLACE FUNCTION dsl.terms_lookup(field text, index text, type text, path text, id text) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('terms', json_build_object(field, ROW(index, type, path, id)::dsl.esqdsl_terms_lookup)))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_range_text AS (lt text, gt text, lte text, gte text, boost real);
CREATE TYPE dsl.esqdsl_range_numeric AS (lt numeric, gt numeric, lte numeric, gte numeric, boost real);
CREATE OR REPLACE FUNCTION dsl.range(field text, lt text DEFAULT NULL, gt text DEFAULT NULL, lte text DEFAULT NULL, gte text DEFAULT NULL, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('range', json_build_object(field, ROW(lt, gt, lte, gte, boost)::dsl.esqdsl_range_text)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.range(field text, lt numeric DEFAULT NULL, gt numeric DEFAULT NULL, lte numeric DEFAULT NULL, gte numeric DEFAULT NULL, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('range', json_build_object(field, ROW(lt, gt, lte, gte, boost)::dsl.esqdsl_range_text)))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_exists AS (field name);
CREATE OR REPLACE FUNCTION dsl.field_exists(field name) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('exists', ROW(field)::dsl.esqdsl_exists))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.field_missing(field name) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT dsl.noteq(dsl.field_exists(field));
$$;


CREATE TYPE dsl.esqdsl_prefix AS (value text, boost real);
CREATE OR REPLACE FUNCTION dsl.prefix(field text, prefix text, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('prefix', json_build_object(field, ROW(prefix, boost)::dsl.esqdsl_prefix)))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_wildcard AS (value text, boost real);
CREATE OR REPLACE FUNCTION dsl.wildcard(field text, wildcard text, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('wildcard', json_build_object(field, ROW(wildcard, boost)::dsl.esqdsl_wildcard)))::zdbquery;
$$;


CREATE TYPE dsl.es_regexp_flags AS ENUM ('ALL', 'ANYSTRING', 'COMPLEMENT', 'EMPTY', 'INTERSECTION', 'INTERVAL', 'NONE');
CREATE TYPE dsl.esqdsl_regexp AS (value text, flags text, max_determined_states int, boost real);
CREATE OR REPLACE FUNCTION dsl.regexp(field text, regexp text, boost real DEFAULT NULL, flags dsl.es_regexp_flags[] DEFAULT NULL, max_determinized_states int DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('regexp', json_build_object(field, ROW(regexp, (SELECT array_to_string(array_agg(DISTINCT flag), '|') FROM unnest(flags) flag), max_determinized_states, boost)::dsl.esqdsl_regexp)))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_fuzzy AS (value text, boost real, fuzziness int, prefix_length int, max_expansions int, transpositions boolean);
CREATE OR REPLACE FUNCTION dsl.fuzzy(field text, value text, boost real DEFAULT NULL, fuzziness int DEFAULT NULL, prefix_length int DEFAULT NULL, max_expansions int DEFAULT NULL, transpositions boolean DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('fuzzy', json_build_object(field, ROW(value, boost, fuzziness, prefix_length, max_expansions, transpositions)::dsl.esqdsl_fuzzy)))::zdbquery;
$$;


CREATE TYPE dsl.es_match_zero_terms_query AS ENUM ('none', 'all');
CREATE TYPE dsl.es_match_operator AS ENUM ('and', 'or');
CREATE TYPE dsl.esqdsl_match AS (query text, boost real, analyzer text, minimum_should_match text, lenient boolean, fuzziness int, fuzzy_rewrite text, fuzzy_transpositions boolean, prefix_length int, zero_terms_query dsl.es_match_zero_terms_query, cutoff_frequency real, operator dsl.es_match_operator, auto_generate_synonyms_phrase_query boolean);
CREATE OR REPLACE FUNCTION dsl.match(field text, query text, boost real DEFAULT NULL, analyzer text DEFAULT NULL, minimum_should_match text DEFAULT NULL, lenient boolean DEFAULT NULL, fuzziness int DEFAULT NULL, fuzzy_rewrite text DEFAULT NULL, fuzzy_transpositions boolean DEFAULT NULL, prefix_length int DEFAULT NULL, zero_terms_query dsl.es_match_zero_terms_query DEFAULT NULL, cutoff_frequency real DEFAULT NULL, operator dsl.es_match_operator DEFAULT NULL, auto_generate_synonyms_phrase_query boolean DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('match', json_build_object(field, ROW(query, boost, analyzer, minimum_should_match, lenient, fuzziness, fuzzy_rewrite, fuzzy_transpositions, prefix_length, zero_terms_query, cutoff_frequency, operator, auto_generate_synonyms_phrase_query)::dsl.esqdsl_match)))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_match_phrase AS (query text, boost real, slop int, analyzer text);
CREATE OR REPLACE FUNCTION dsl.match_phrase(field text, query text, boost real DEFAULT NULL, slop int DEFAULT NULL, analyzer text DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('match_phrase', json_build_object(field, ROW(query, boost, slop, analyzer)::dsl.esqdsl_match_phrase)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.phrase(field text, query text, boost real DEFAULT NULL, slop int DEFAULT NULL, analyzer text DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT dsl.match_phrase(field, query, boost, slop, analyzer);
$$;


CREATE TYPE dsl.esqdsl_match_phrase_prefix AS (query text, boost real, slop int, analyzer text, max_expansions int);
CREATE OR REPLACE FUNCTION dsl.match_phrase_prefix(field text, query text, boost real DEFAULT NULL, slop int DEFAULT NULL, analyzer text DEFAULT NULL, max_expansions int DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('match_phrase_prefix', json_build_object(field, ROW(query, boost, slop, analyzer, max_expansions)::dsl.esqdsl_match_phrase_prefix)))::zdbquery;
$$;


CREATE TYPE dsl.es_multi_match_type AS ENUM ('best_fields', 'most_fields', 'cross_fields', 'phrase', 'phrase_prefix');
CREATE TYPE dsl.esqdsl_multi_match AS (fields name[], type dsl.es_multi_match_type, query text, boost real, analyzer text, minimum_should_match text, lenient boolean, fuzziness int, fuzzy_rewrite text, fuzzy_transpositions boolean, prefix_length int, zero_terms_query dsl.es_match_zero_terms_query, cutoff_frequency real, operator dsl.es_match_operator, auto_generate_synonyms_phrase_query boolean);
CREATE OR REPLACE FUNCTION dsl.multi_match(fields name[], query text, boost real DEFAULT NULL, type dsl.es_multi_match_type DEFAULT NULL, analyzer text DEFAULT NULL, minimum_should_match text DEFAULT NULL, lenient boolean DEFAULT NULL, fuzziness int DEFAULT NULL, fuzzy_rewrite text DEFAULT NULL, fuzzy_transpositions boolean DEFAULT NULL, prefix_length int DEFAULT NULL, zero_terms_query dsl.es_match_zero_terms_query DEFAULT NULL, cutoff_frequency real DEFAULT NULL, operator dsl.es_match_operator DEFAULT NULL, auto_generate_synonyms_phrase_query boolean DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('multi_match', ROW(fields, type, query, boost, analyzer, minimum_should_match, lenient, fuzziness, fuzzy_rewrite, fuzzy_transpositions, prefix_length, zero_terms_query, cutoff_frequency, operator, auto_generate_synonyms_phrase_query)::dsl.esqdsl_multi_match))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_common AS (query text, boost real, cutoff_frequency real, analyzer text, minimum_should_match text);
CREATE OR REPLACE FUNCTION dsl.common(field text, query text, boost real DEFAULT NULL, cutoff_frequency real DEFAULT NULL, analyzer text DEFAULT NULL, minimum_should_match text DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('common', json_build_object(field, ROW(query, boost, cutoff_frequency, analyzer, minimum_should_match)::dsl.esqdsl_common)))::zdbquery;
$$;


CREATE OR REPLACE FUNCTION dsl.constant_score(query zdbquery, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('constant_score', json_build_object('filter', query), 'boost', boost))::zdbquery;
$$;

CREATE TYPE dsl.esqdsl_dis_max AS (queries zdbquery[], tie_breaker real, boost real);
CREATE OR REPLACE FUNCTION dsl.dis_max(queries zdbquery[], boost real DEFAULT NULL, tie_breaker real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('dis_max', ROW(queries, tie_breaker, boost)::dsl.esqdsl_dis_max))::zdbquery;
$$;


CREATE TYPE dsl.esqdsl_more_like_this AS (fields name[], "like" text[], boost real, unlike text, analyzer text, stop_words text[], minimum_should_match text, boost_terms real, include boolean, min_term_freq int, max_query_terms int, min_doc_freq int, max_doc_freq int, min_word_length int, max_word_length int);
CREATE OR REPLACE FUNCTION dsl.more_like_this("like" text[], fields name[] DEFAULT NULL, stop_words text[] DEFAULT ARRAY[
            'http', 'span', 'class', 'flashtext', 'let', 'its',
            'may', 'well', 'got', 'too', 'them', 'really', 'new', 'set', 'please',
            'how', 'our', 'from', 'sent', 'subject', 'sincerely', 'thank', 'thanks',
            'just', 'get', 'going', 'were', 'much', 'can', 'also', 'she', 'her',
            'him', 'his', 'has', 'been', 'ok', 'still', 'okay', 'does', 'did',
            'about', 'yes', 'you', 'your', 'when', 'know', 'have', 'who', 'what',
            'where', 'sir', 'page', 'a', 'an', 'and', 'are', 'as', 'at', 'be',
            'but', 'by', 'for', 'if', 'in', 'into', 'is', 'it', 'no', 'not', 'of',
            'on', 'or', 'such', 'that', 'the', 'their', 'than', 'then', 'there',
            'these', 'they', 'this', 'to', 'was', 'will', 'with'], boost real DEFAULT NULL, unlike text DEFAULT NULL, analyzer text DEFAULT NULL, minimum_should_match text DEFAULT NULL, boost_terms real DEFAULT NULL, include boolean DEFAULT NULL, min_term_freq int DEFAULT NULL, max_query_terms int DEFAULT NULL, min_doc_freq int DEFAULT NULL, max_doc_freq int DEFAULT NULL, min_word_length int DEFAULT NULL, max_word_length int DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('more_like_this', ROW(fields, "like", boost, unlike, analyzer, stop_words, minimum_should_match, boost_terms, include, min_term_freq, max_query_terms, min_doc_freq, max_doc_freq, min_word_length, max_word_length)::dsl.esqdsl_more_like_this))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.more_like_this("like" text, fields name[] DEFAULT NULL, stop_words text[] DEFAULT ARRAY[
            'http', 'span', 'class', 'flashtext', 'let', 'its',
            'may', 'well', 'got', 'too', 'them', 'really', 'new', 'set', 'please',
            'how', 'our', 'from', 'sent', 'subject', 'sincerely', 'thank', 'thanks',
            'just', 'get', 'going', 'were', 'much', 'can', 'also', 'she', 'her',
            'him', 'his', 'has', 'been', 'ok', 'still', 'okay', 'does', 'did',
            'about', 'yes', 'you', 'your', 'when', 'know', 'have', 'who', 'what',
            'where', 'sir', 'page', 'a', 'an', 'and', 'are', 'as', 'at', 'be',
            'but', 'by', 'for', 'if', 'in', 'into', 'is', 'it', 'no', 'not', 'of',
            'on', 'or', 'such', 'that', 'the', 'their', 'than', 'then', 'there',
            'these', 'they', 'this', 'to', 'was', 'will', 'with'], boost real DEFAULT NULL, unlike text DEFAULT NULL, analyzer text DEFAULT NULL, minimum_should_match text DEFAULT NULL, boost_terms real DEFAULT NULL, include boolean DEFAULT NULL, min_term_freq int DEFAULT NULL, max_query_terms int DEFAULT NULL, min_doc_freq int DEFAULT NULL, max_doc_freq int DEFAULT NULL, min_word_length int DEFAULT NULL, max_word_length int DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('more_like_this', ROW(fields, ARRAY["like"], boost, unlike, analyzer, stop_words, minimum_should_match, boost_terms, include, min_term_freq, max_query_terms, min_doc_freq, max_doc_freq, min_word_length, max_word_length)::dsl.esqdsl_more_like_this))::zdbquery;
$$;

CREATE TYPE dsl.esqdsl_script AS (source text, lang text, params json);
CREATE FUNCTION dsl.params(VARIADIC "any") RETURNS json PARALLEL SAFE IMMUTABLE LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_json_build_object_wrapper';
CREATE OR REPLACE FUNCTION dsl.script(source_code text, params json DEFAULT NULL, lang text DEFAULT 'painless') RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('script', json_build_object('script', ROW(source_code, lang, params)::dsl.esqdsl_script)))::zdbquery;
$$;

CREATE TYPE dsl.esqdsl_boosting AS (positive zdbquery, negative zdbquery, negative_boost real);
CREATE OR REPLACE FUNCTION dsl.boosting(positive zdbquery, negative zdbquery, negative_boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('boosting', ROW(positive, negative, negative_boost)::dsl.esqdsl_boosting))::zdbquery;
$$;

CREATE TYPE dsl.es_nested_score_mode AS ENUM ('avg', 'sum', 'min', 'max', 'none');
CREATE TYPE dsl.esqdsl_nested AS (path text, query zdbquery, score_mode dsl.es_nested_score_mode);
CREATE OR REPLACE FUNCTION dsl.nested(path text, query zdbquery, score_mode dsl.es_nested_score_mode DEFAULT 'avg'::dsl.es_nested_score_mode) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('nested', ROW(path, query, score_mode)::dsl.esqdsl_nested))::zdbquery;
$$;

CREATE OR REPLACE FUNCTION dsl.span_term(field text, value text, boost real DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_term', json_build_object(field, ROW(value, boost)::dsl.esqdsl_term_text)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.span_multi(query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_multi', json_build_object('match', query)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.span_first(query zdbquery, "end" int) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_first', json_build_object('match', query), 'end', "end"))::zdbquery;
$$;

CREATE TYPE dsl.esqdsl_span_near AS (clauses zdbquery[], slop int, in_order boolean);
CREATE OR REPLACE FUNCTION dsl.span_near(in_order boolean, slop int, VARIADIC clauses zdbquery[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_near', ROW(clauses, slop, in_order)::dsl.esqdsl_span_near))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.span_or(VARIADIC clauses zdbquery[]) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_or', json_build_object('clauses', clauses)))::zdbquery;
$$;

CREATE TYPE dsl.esqdsl_span_not AS (include zdbquery, exclude zdbquery, pre int, post int, dist int);
CREATE OR REPLACE FUNCTION dsl.span_not(include zdbquery, exclude zdbquery, pre int DEFAULT NULL, post int DEFAULT NULL, dist int DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_not', ROW(include, exclude, pre, post, dist)::dsl.esqdsl_span_not))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.span_containing(little zdbquery, big zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_containing', json_build_object('little', little, 'big', big)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.span_within(little zdbquery, big zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('span_within', json_build_object('little', little, 'big', big)))::zdbquery;
$$;
CREATE OR REPLACE FUNCTION dsl.span_masking(field text, query zdbquery) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('field_masking_span', json_build_object('query', query, 'field', field)))::zdbquery;
$$;

CREATE TYPE dsl.esqdsl_default_operators AS ENUM ('AND', 'OR');
CREATE TYPE dsl.esqdsl_query_string AS (query text, default_field text, default_operator dsl.esqdsl_default_operators, analyzer text, quote_analyzer text, allow_leading_wildcard boolean, enable_position_increments boolean, fuzzy_max_expansions integer, fuzziness text, fuzzy_prefix_length integer, fuzzy_transpositions boolean, phrase_slop integer, boost real, auto_generate_phrase_queries boolean, analyze_wildcard boolean, max_determinized_states integer, minimum_should_match integer, lenient boolean, time_zone text, quote_field_suffix text, auto_generate_synonyms_phrase_query boolean, all_fields boolean);
CREATE OR REPLACE FUNCTION dsl.query_string(
    query text,
    default_operator dsl.esqdsl_default_operators DEFAULT NULL,
    default_field text DEFAULT NULL,
    analyzer text DEFAULT NULL,
    quote_analyzer text DEFAULT NULL,
    allow_leading_wildcard boolean DEFAULT NULL,
    enable_position_increments boolean DEFAULT NULL,
    fuzzy_max_expansions integer DEFAULT NULL,
    fuzziness text DEFAULT NULL,
    fuzzy_prefix_length integer DEFAULT NULL,
    fuzzy_transpositions boolean DEFAULT NULL,
    phrase_slop integer DEFAULT NULL,
    boost real DEFAULT NULL,
    auto_generate_phrase_queries boolean DEFAULT NULL,
    analyze_wildcard boolean DEFAULT NULL,
    max_determinized_states integer DEFAULT NULL,
    minimum_should_match integer DEFAULT NULL,
    lenient boolean DEFAULT NULL,
    time_zone text DEFAULT NULL,
    quote_field_suffix text DEFAULT NULL,
    auto_generate_synonyms_phrase_query boolean DEFAULT NULL,
    all_fields boolean DEFAULT NULL) RETURNS zdbquery PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(json_build_object('query_string', ROW(query, default_field, default_operator, analyzer,
                                quote_analyzer, allow_leading_wildcard, enable_position_increments, fuzzy_max_expansions,
                                fuzziness, fuzzy_prefix_length, fuzzy_transpositions, phrase_slop, boost,
                                auto_generate_phrase_queries, analyze_wildcard, max_determinized_states,
                                minimum_should_match, lenient, time_zone, quote_field_suffix,
                                auto_generate_synonyms_phrase_query, all_fields)::dsl.esqdsl_query_string))::zdbquery;
$$;
--
-- table samplers
--
CREATE OR REPLACE FUNCTION sampler(internal) RETURNS tsm_handler IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_table_sampler';
CREATE OR REPLACE FUNCTION diversified_sampler(internal) RETURNS tsm_handler IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_diversified_table_sampler';
CREATE OR REPLACE FUNCTION query_sampler(internal) RETURNS tsm_handler IMMUTABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_query_table_sampler';

--
-- simple cross-index join support... requires both dsl and agg functions already created
--
CREATE OR REPLACE FUNCTION dsl.join(left_field text, index regclass, right_field text, query zdbquery, size int DEFAULT 0) RETURNS zdbquery PARALLEL SAFE STABLE LANGUAGE plpgsql AS $$
BEGIN
    IF size > 0 THEN
        /* if we have a size limit, then limit to the top matching hits */
        RETURN dsl.filter(dsl.terms(left_field, VARIADIC (SELECT array_agg(source->>right_field) FROM zdb.top_hits(index, ARRAY[right_field], query, size))));
    ELSE
        /* otherwise, return all the matching terms */
        RETURN dsl.filter(dsl.terms(left_field, VARIADIC zdb.terms_array(index, right_field, query)));
    END IF;
END;
$$;

--
-- scoring support
--
CREATE OR REPLACE FUNCTION score(ctid tid) RETURNS float4 PARALLEL UNSAFE LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_score';

--
-- highlighting composition functions
--
CREATE TYPE esqdsl_highlight_type AS ENUM ('unified', 'plain', 'fvh');
CREATE TYPE esqdsl_fragmenter_type AS ENUM ('simple', 'span');
CREATE TYPE esqdsl_encoder_type AS ENUM ('default', 'html');
CREATE TYPE esqdsl_boundary_scanner_type AS ENUM ('chars', 'sentence', 'word');

CREATE TYPE esqdsl_highlight AS (
    type zdb.esqdsl_highlight_type,
    number_of_fragments int,
    pre_tags text[],
    post_tags text[],
    tags_schema text,
    require_field_match boolean,

    highlight_query zdbquery,

    no_match_size int,
    fragmenter zdb.esqdsl_fragmenter_type,
    fragment_size int,
    fragment_offset int,
    force_source boolean,
    encoder zdb.esqdsl_encoder_type,
    boundary_scanner_locale text,
    boundary_scan_max int,
    boundary_chars text,
    phrase_limit int,

    matched_fields boolean,
    "order" text
);
CREATE OR REPLACE FUNCTION highlight(
    type zdb.esqdsl_highlight_type DEFAULT NULL,
    require_field_match boolean DEFAULT false,
    number_of_fragments int DEFAULT NULL,
    highlight_query zdbquery DEFAULT NULL,
    pre_tags text[] DEFAULT NULL,
    post_tags text[] DEFAULT NULL,
    tags_schema text DEFAULT NULL,
    no_match_size int DEFAULT NULL,

    fragmenter zdb.esqdsl_fragmenter_type DEFAULT NULL,
    fragment_size int DEFAULT NULL,
    fragment_offset int DEFAULT NULL,
    force_source boolean DEFAULT true,
    encoder zdb.esqdsl_encoder_type DEFAULT NULL,
    boundary_scanner_locale text DEFAULT NULL,
    boundary_scan_max int DEFAULT NULL,
    boundary_chars text DEFAULT NULL,
    phrase_limit int DEFAULT NULL,

    matched_fields boolean DEFAULT NULL,
    "order" text DEFAULT NULL
) RETURNS json PARALLEL UNSAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT json_strip_nulls(row_to_json(
             ROW(type, number_of_fragments, pre_tags, post_tags, tags_schema,
                require_field_match, highlight_query, no_match_size, fragmenter,
                fragment_size, fragment_offset, force_source, encoder, boundary_scanner_locale,
                boundary_scan_max, boundary_chars, phrase_limit,
                matched_fields, "order"
        )::zdb.esqdsl_highlight)
    );
$$;
CREATE OR REPLACE FUNCTION highlight(ctid tid, field text, highlight_definition json DEFAULT highlight()) RETURNS text[] PARALLEL UNSAFE STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_highlight';
CREATE OR REPLACE FUNCTION zdb.vac_by_xmin(index regclass, type text, xmin bigint) RETURNS zdbquery PARALLEL SAFE STABLE STRICT LANGUAGE sql AS $$
/*
 * docs with aborted xmins
 */
    SELECT dsl.and(
        dsl.range(field=>'zdb_xmin', lt=>xmin),
        dsl.terms_lookup('zdb_xmin', zdb.index_name(index), type, 'zdb_aborted_xids', 'zdb_aborted_xids')
    );
$$;

CREATE OR REPLACE FUNCTION zdb.vac_by_xmax(index regclass, type text, xmax bigint) RETURNS zdbquery PARALLEL SAFE STABLE STRICT LANGUAGE sql AS $$
/*
 * docs with committed xmax
 */
    SELECT dsl.and(
        dsl.range(field=>'zdb_xmax', lt=>xmax),
        dsl.noteq(dsl.terms_lookup('zdb_xmax', zdb.index_name(index), type, 'zdb_aborted_xids', 'zdb_aborted_xids'))
    );
$$;

CREATE OR REPLACE FUNCTION zdb.vac_aborted_xmax(index regclass, type text, xmax bigint) RETURNS zdbquery PARALLEL SAFE STABLE STRICT LANGUAGE sql AS $$
/*
 * docs with aborted xmax
 */
    SELECT dsl.and(
        dsl.range(field=>'zdb_xmax', lt=>xmax),
        dsl.terms_lookup('zdb_xmax', zdb.index_name(index), type, 'zdb_aborted_xids', 'zdb_aborted_xids')
    );
$$;

CREATE OR REPLACE FUNCTION zdb.internal_visibility_clause(index regclass) RETURNS zdbquery PARALLEL SAFE STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_visibility_clause';
--
-- aggregate support functions
--
CREATE OR REPLACE FUNCTION count(index regclass, query zdbquery) RETURNS bigint PARALLEL SAFE STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_count';
CREATE OR REPLACE FUNCTION raw_count(index regclass, query zdbquery) RETURNS bigint SET zdb.ignore_visibility = true PARALLEL SAFE STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_count';
CREATE OR REPLACE FUNCTION arbitrary_agg(index regclass, query zdbquery, agg_json json) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_arbitrary_agg';

CREATE TYPE terms_order AS ENUM ('count', 'term', 'reverse_count', 'reverse_term');
CREATE OR REPLACE FUNCTION internal_terms(index regclass, field text, query zdbquery, order_by text, size_limit bigint) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_terms';
CREATE OR REPLACE FUNCTION terms(index regclass, field text, query zdbquery, size_limit bigint DEFAULT 0, order_by terms_order DEFAULT 'count') RETURNS TABLE (term text, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_terms(index, field, query, order_by::text, size_limit)::jsonb;
BEGIN
    RETURN QUERY SELECT entry->>'key', (entry->>'doc_count')::bigint FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;
CREATE OR REPLACE FUNCTION internal_terms_array(index regclass, field text, query zdbquery, order_by text, size_limit bigint) RETURNS text[] STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_terms_array';
CREATE OR REPLACE FUNCTION terms_array(index regclass, field text, query zdbquery, size_limit bigint DEFAULT 0, order_by terms_order DEFAULT 'count') RETURNS text[] LANGUAGE sql AS $$
    SELECT zdb.internal_terms_array(index, field, query, order_by::text, size_limit);
$$;

CREATE OR REPLACE FUNCTION internal_terms_two_level(index regclass, first_field text, second_field text, query zdbquery, order_by text, size bigint) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_terms_two_level';
CREATE OR REPLACE FUNCTION terms_two_level(index regclass, first_field text, second_field text, query zdbquery, order_by terms_order DEFAULT 'count', size bigint DEFAULT 0) RETURNS TABLE (first_term text, second_term text, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_terms_two_level(index, first_field, second_field, query, order_by::text, size)::jsonb;
BEGIN
    RETURN QUERY
                SELECT entry->>'key',
                       jsonb_array_elements(entry->'sub_agg'->'buckets')->>'key',
                       (jsonb_array_elements(entry->'sub_agg'->'buckets')->>'doc_count')::bigint
                  FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_avg(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_avg';
CREATE OR REPLACE FUNCTION avg(index regclass, field text, query zdbquery) RETURNS numeric LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_avg(index, field, query)::jsonb;
BEGIN
    RETURN (response->'aggregations'->'the_agg'->>'value')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_min(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_min';
CREATE OR REPLACE FUNCTION min(index regclass, field text, query zdbquery) RETURNS numeric LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_min(index, field, query)::jsonb;
BEGIN
    RETURN (response->'aggregations'->'the_agg'->>'value')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_max(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_max';
CREATE OR REPLACE FUNCTION max(index regclass, field text, query zdbquery) RETURNS numeric LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_max(index, field, query)::jsonb;
BEGIN
    RETURN (response->'aggregations'->'the_agg'->>'value')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_cardinality(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_cardinality';
CREATE OR REPLACE FUNCTION cardinality(index regclass, field text, query zdbquery) RETURNS numeric LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_cardinality(index, field, query)::jsonb;
BEGIN
    RETURN (response->'aggregations'->'the_agg'->>'value')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_sum(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_sum';
CREATE OR REPLACE FUNCTION sum(index regclass, field text, query zdbquery) RETURNS numeric LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_sum(index, field, query)::jsonb;
BEGIN
    RETURN (response->'aggregations'->'the_agg'->>'value')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_value_count(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_value_count';
CREATE OR REPLACE FUNCTION value_count(index regclass, field text, query zdbquery) RETURNS numeric LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_value_count(index, field, query)::jsonb;
BEGIN
    RETURN (response->'aggregations'->'the_agg'->>'value')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_percentiles(index regclass, field text, query zdbquery, percents text) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_percentiles';
CREATE OR REPLACE FUNCTION percentiles(index regclass, field text, query zdbquery, percents text DEFAULT '') RETURNS TABLE (percentile numeric, value numeric) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_percentiles(index, field, query, percents)::jsonb;
BEGIN
    RETURN QUERY select key::numeric, jsonb_object_field_text(json, key)::numeric
                   from (select key, response->'aggregations'->'the_agg'->'values' as json
                           from jsonb_object_keys(response->'aggregations'->'the_agg'->'values') key
                        ) x;
END;
$$;

CREATE OR REPLACE FUNCTION internal_percentile_ranks(index regclass, field text, query zdbquery, "values" text) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_percentile_ranks';
CREATE OR REPLACE FUNCTION percentile_ranks(index regclass, field text, query zdbquery, "values" text DEFAULT '') RETURNS TABLE (percentile numeric, value numeric) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_percentile_ranks(index, field, query, "values")::jsonb;
BEGIN
    RETURN QUERY select key::numeric, jsonb_object_field_text(json, key)::numeric
                   from (select key, response->'aggregations'->'the_agg'->'values' as json
                           from jsonb_object_keys(response->'aggregations'->'the_agg'->'values') key
                        ) x;
END;
$$;

CREATE OR REPLACE FUNCTION internal_stats(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_stats';
CREATE OR REPLACE FUNCTION stats(index regclass, field text, query zdbquery) RETURNS TABLE (count bigint, min numeric, max numeric, avg numeric, sum numeric) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_stats(index, field, query)::jsonb;
BEGIN
    RETURN QUERY
        SELECT
            (response->'aggregations'->'the_agg'->>'count')::bigint,
            (response->'aggregations'->'the_agg'->>'min')::numeric,
            (response->'aggregations'->'the_agg'->>'max')::numeric,
            (response->'aggregations'->'the_agg'->>'avg')::numeric,
            (response->'aggregations'->'the_agg'->>'sum')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_extended_stats(index regclass, field text, query zdbquery, sigma int) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_extended_stats';
CREATE OR REPLACE FUNCTION extended_stats(index regclass, field text, query zdbquery, sigma int DEFAULT 0) RETURNS TABLE (count bigint, min numeric, max numeric, avg numeric, sum numeric, sum_of_squares numeric, variance numeric, stddev numeric, stddev_upper numeric, stddev_lower numeric) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_extended_stats(index, field, query, sigma)::jsonb;
BEGIN
    RETURN QUERY
        SELECT
            (response->'aggregations'->'the_agg'->>'count')::bigint,
            (response->'aggregations'->'the_agg'->>'min')::numeric,
            (response->'aggregations'->'the_agg'->>'max')::numeric,
            (response->'aggregations'->'the_agg'->>'avg')::numeric,
            (response->'aggregations'->'the_agg'->>'sum')::numeric,
            (response->'aggregations'->'the_agg'->>'sum_of_squares')::numeric,
            (response->'aggregations'->'the_agg'->>'variance')::numeric,
            (response->'aggregations'->'the_agg'->>'std_deviation')::numeric,
            (response->'aggregations'->'the_agg'->'std_deviation_bounds'->>'upper')::numeric,
            (response->'aggregations'->'the_agg'->'std_deviation_bounds'->>'lower')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_significant_terms(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_significant_terms';
CREATE OR REPLACE FUNCTION significant_terms(index regclass, field text, query zdbquery) RETURNS TABLE (term text, doc_count bigint, score numeric, bg_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_significant_terms(index, field, query)::jsonb;
BEGIN
    RETURN QUERY SELECT NULL::text, (response->'aggregations'->'the_agg'->>'doc_count')::bigint, NULL::numeric, (response->'aggregations'->'the_agg'->>'bg_count')::bigint
                        UNION ALL
                SELECT entry->>'key', (entry->>'doc_count')::bigint, (entry->>'score')::numeric, (entry->>'bg_count')::bigint
                  FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_significant_terms_two_level(index regclass, first_field text, second_field text, query zdbquery, size bigint) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_significant_terms_two_level';
CREATE OR REPLACE FUNCTION significant_terms_two_level(index regclass, first_field text, second_field text, query zdbquery, size bigint DEFAULT 0) RETURNS TABLE (first_term text, second_term text, doc_count bigint, score numeric, bg_count bigint, doc_count_error_upper_bound bigint, sum_other_doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_significant_terms_two_level(index, first_field, second_field, query, size)::jsonb;
BEGIN
    RETURN QUERY
                SELECT NULL::text, NULL::text, NULL::bigint, NULL::numeric, NULL::bigint,
                       (response->'aggregations'->'the_agg'->>'doc_count_error_upper_bound')::bigint,
                       (response->'aggregations'->'the_agg'->>'sum_other_doc_count')::bigint
                          UNION ALL
                SELECT entry->>'key',
                       jsonb_array_elements(entry->'sub_agg'->'buckets')->>'key',
                       (jsonb_array_elements(entry->'sub_agg'->'buckets')->>'doc_count')::bigint,
                       (jsonb_array_elements(entry->'sub_agg'->'buckets')->>'score')::numeric,
                       (jsonb_array_elements(entry->'sub_agg'->'buckets')->>'bg_count')::bigint,
                       NULL::bigint, NULL::bigint
                  FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_range(index regclass, field text, query zdbquery, ranges_array json) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_range';
CREATE OR REPLACE FUNCTION range(index regclass, field text, query zdbquery, ranges_array json) RETURNS TABLE (key text, "from" numeric, "to" numeric, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_range(index, field, query, ranges_array)::jsonb;
BEGIN
    RETURN QUERY SELECT entry->>'key',
                        (entry->>'from')::numeric,
                        (entry->>'to')::numeric,
                        (entry->>'doc_count')::bigint
                   FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_date_range(index regclass, field text, query zdbquery, date_ranges_array json) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_date_range';
CREATE OR REPLACE FUNCTION date_range(index regclass, field text, query zdbquery, date_ranges_array json) RETURNS TABLE (key text, "from" numeric, from_as_string timestamp with time zone, "to" numeric, to_as_string timestamp with time zone, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_date_range(index, field, query, date_ranges_array)::jsonb;
BEGIN
    RETURN QUERY SELECT entry->>'key',
                        (entry->>'from')::numeric,
                        (entry->>'from_as_string')::timestamp with time zone,
                        (entry->>'to')::numeric,
                        (entry->>'to_as_string')::timestamp with time zone,
                        (entry->>'doc_count')::bigint
                   FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_histogram(index regclass, field text, query zdbquery, "interval" float8) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_histogram';
CREATE OR REPLACE FUNCTION histogram(index regclass, field text, query zdbquery, "interval" float8) RETURNS TABLE (key numeric, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_histogram(index, field, query, "interval")::jsonb;
BEGIN
    RETURN QUERY SELECT (entry->>'key')::numeric,
                        (entry->>'doc_count')::bigint
                   FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_date_histogram(index regclass, field text, query zdbquery, "interval" text, format text) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_date_histogram';
CREATE OR REPLACE FUNCTION date_histogram(index regclass, field text, query zdbquery, "interval" text, format text DEFAULT 'yyyy-MM-dd') RETURNS TABLE (key numeric, key_as_string text, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_date_histogram(index, field, query, "interval", format)::jsonb;
BEGIN
    RETURN QUERY SELECT (entry->>'key')::numeric,
                        entry->>'key_as_string',
                        (entry->>'doc_count')::bigint
                   FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_missing(index regclass, field text, query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_missing';
CREATE OR REPLACE FUNCTION missing(index regclass, field text, query zdbquery) RETURNS numeric LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_missing(index, field, query)::jsonb;
BEGIN
    RETURN (response->'aggregations'->'the_agg'->>'doc_count')::numeric;
END;
$$;

CREATE OR REPLACE FUNCTION internal_filters(index regclass, labels text[], filters zdbquery[]) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_filters';
CREATE OR REPLACE FUNCTION filters(index regclass, labels text[], filters zdbquery[]) RETURNS TABLE (label text, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_filters(index, labels, filters)::jsonb;
BEGIN
    RETURN QUERY SELECT entry::text,
                        (response->'aggregations'->'the_agg'->'buckets'->entry->>'doc_count')::bigint
                   FROM jsonb_object_keys(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_ip_range(index regclass, field text, query zdbquery, ip_ranges_array json) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_ip_range';
CREATE OR REPLACE FUNCTION ip_range(index regclass, field text, query zdbquery, ip_ranges_array json) RETURNS TABLE (key text, "from" inet, "to" inet, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_ip_range(index, field, query, ip_ranges_array)::jsonb;
BEGIN
    RETURN QUERY SELECT entry->>'key',
                        (entry->>'from')::inet,
                        (entry->>'to')::inet,
                        (entry->>'doc_count')::bigint
                   FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_significant_text(index regclass, field text, query zdbquery, sample_size int, filter_duplicate_text boolean) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_significant_text';
CREATE OR REPLACE FUNCTION significant_text(index regclass, field text, query zdbquery, sample_size int DEFAULT 0, filter_duplicate_text boolean DEFAULT true) RETURNS TABLE (term text, doc_count bigint, score numeric, bg_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_significant_text(index, field, query, sample_size, filter_duplicate_text)::jsonb;
BEGIN
    RETURN QUERY SELECT NULL::text, (response->'aggregations'->'the_agg'->>'doc_count')::bigint, NULL::numeric, (response->'aggregations'->'the_agg'->>'bg_count')::bigint
                        UNION ALL
                SELECT entry->>'key', (entry->>'doc_count')::bigint, (entry->>'score')::numeric, (entry->>'bg_count')::bigint
                  FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION internal_adjacency_matrix(index regclass, labels text[], filters zdbquery[]) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_adjacency_matrix';
CREATE OR REPLACE FUNCTION adjacency_matrix(index regclass, labels text[], filters zdbquery[]) RETURNS TABLE (key text, doc_count bigint) LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_adjacency_matrix(index, labels, filters)::jsonb;
BEGIN
    RETURN QUERY SELECT entry->>'key',
                        (entry->>'doc_count')::bigint
                   FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'buckets') entry;
END;
$$;

CREATE OR REPLACE FUNCTION adjacency_matrix_2x2(index regclass, labels text[], filters zdbquery[]) RETURNS TABLE ("-" text, "1" text, "2" text) STABLE LANGUAGE sql AS $$

WITH matrix AS (SELECT key, doc_count::text FROM zdb.adjacency_matrix(index, labels, filters))
SELECT NULL::text, labels[1], labels[2]
   UNION ALL
SELECT labels[1],
    (SELECT doc_count FROM matrix WHERE key = labels[1]),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[2], labels[2]||'&'||labels[1]))
   UNION ALL
SELECT labels[2],
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[1], labels[1]||'&'||labels[2])),
    (SELECT doc_count FROM matrix WHERE key = labels[2])

$$;

CREATE OR REPLACE FUNCTION adjacency_matrix_3x3(index regclass, labels text[], filters zdbquery[]) RETURNS TABLE ("-" text, "1" text, "2" text, "3" text) STABLE LANGUAGE sql AS $$

WITH matrix AS (SELECT key, doc_count::text FROM zdb.adjacency_matrix(index, labels, filters))
SELECT NULL::text, labels[1], labels[2], labels[3]
   UNION ALL
SELECT labels[1],
    (SELECT doc_count FROM matrix WHERE key = labels[1]),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[2], labels[2]||'&'||labels[1])),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[3], labels[3]||'&'||labels[1]))
   UNION ALL
SELECT labels[2],
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[1], labels[1]||'&'||labels[2])),
    (SELECT doc_count FROM matrix WHERE key = labels[2]),
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[3], labels[3]||'&'||labels[2]))
   UNION ALL
SELECT labels[3],
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[1], labels[1]||'&'||labels[3])),
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[2], labels[2]||'&'||labels[3])),
    (SELECT doc_count FROM matrix WHERE key = labels[3])

$$;

CREATE OR REPLACE FUNCTION adjacency_matrix_4x4(index regclass, labels text[], filters zdbquery[]) RETURNS TABLE ("-" text, "1" text, "2" text, "3" text, "4" text) STABLE LANGUAGE sql AS $$

WITH matrix AS (SELECT key, doc_count::text FROM zdb.adjacency_matrix(index, labels, filters))
SELECT NULL::text, labels[1], labels[2], labels[3], labels[4]
   UNION ALL
SELECT labels[1],
    (SELECT doc_count FROM matrix WHERE key = labels[1]),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[2], labels[2]||'&'||labels[1])),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[3], labels[3]||'&'||labels[1])),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[4], labels[4]||'&'||labels[1]))
   UNION ALL
SELECT labels[2],
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[1], labels[1]||'&'||labels[2])),
    (SELECT doc_count FROM matrix WHERE key = labels[2]),
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[3], labels[3]||'&'||labels[2])),
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[4], labels[4]||'&'||labels[2]))
   UNION ALL
SELECT labels[3],
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[1], labels[1]||'&'||labels[3])),
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[2], labels[2]||'&'||labels[3])),
    (SELECT doc_count FROM matrix WHERE key = labels[3]),
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[4], labels[4]||'&'||labels[3]))
   UNION ALL
SELECT labels[4],
    (SELECT doc_count FROM matrix WHERE key in (labels[4]||'&'||labels[1], labels[1]||'&'||labels[4])),
    (SELECT doc_count FROM matrix WHERE key in (labels[4]||'&'||labels[2], labels[2]||'&'||labels[4])),
    (SELECT doc_count FROM matrix WHERE key in (labels[4]||'&'||labels[3], labels[3]||'&'||labels[4])),
    (SELECT doc_count FROM matrix WHERE key = labels[4])

$$;

CREATE OR REPLACE FUNCTION adjacency_matrix_5x5(index regclass, labels text[], filters zdbquery[]) RETURNS TABLE ("-" text, "1" text, "2" text, "3" text, "4" text, "5" text) STABLE LANGUAGE sql AS $$

WITH matrix AS (SELECT key, doc_count::text FROM zdb.adjacency_matrix(index, labels, filters))
SELECT NULL::text, labels[1], labels[2], labels[3], labels[4], labels[5]
   UNION ALL
SELECT labels[1],
    (SELECT doc_count FROM matrix WHERE key = labels[1]),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[2], labels[2]||'&'||labels[1])),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[3], labels[3]||'&'||labels[1])),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[4], labels[4]||'&'||labels[1])),
    (SELECT doc_count FROM matrix WHERE key in (labels[1]||'&'||labels[5], labels[5]||'&'||labels[1]))
   UNION ALL
SELECT labels[2],
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[1], labels[1]||'&'||labels[2])),
    (SELECT doc_count FROM matrix WHERE key = labels[2]),
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[3], labels[3]||'&'||labels[2])),
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[4], labels[4]||'&'||labels[2])),
    (SELECT doc_count FROM matrix WHERE key in (labels[2]||'&'||labels[5], labels[5]||'&'||labels[2]))
   UNION ALL
SELECT labels[3],
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[1], labels[1]||'&'||labels[3])),
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[2], labels[2]||'&'||labels[3])),
    (SELECT doc_count FROM matrix WHERE key = labels[3]),
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[4], labels[4]||'&'||labels[3])),
    (SELECT doc_count FROM matrix WHERE key in (labels[3]||'&'||labels[5], labels[5]||'&'||labels[3]))
   UNION ALL
SELECT labels[4],
    (SELECT doc_count FROM matrix WHERE key in (labels[4]||'&'||labels[1], labels[1]||'&'||labels[4])),
    (SELECT doc_count FROM matrix WHERE key in (labels[4]||'&'||labels[2], labels[2]||'&'||labels[4])),
    (SELECT doc_count FROM matrix WHERE key in (labels[4]||'&'||labels[3], labels[3]||'&'||labels[4])),
    (SELECT doc_count FROM matrix WHERE key = labels[4]),
    (SELECT doc_count FROM matrix WHERE key in (labels[4]||'&'||labels[5], labels[5]||'&'||labels[4]))
   UNION ALL
SELECT labels[5],
    (SELECT doc_count FROM matrix WHERE key in (labels[5]||'&'||labels[1], labels[1]||'&'||labels[5])),
    (SELECT doc_count FROM matrix WHERE key in (labels[5]||'&'||labels[2], labels[2]||'&'||labels[5])),
    (SELECT doc_count FROM matrix WHERE key in (labels[5]||'&'||labels[3], labels[3]||'&'||labels[5])),
    (SELECT doc_count FROM matrix WHERE key in (labels[5]||'&'||labels[4], labels[4]||'&'||labels[5])),
    (SELECT doc_count FROM matrix WHERE key = labels[5])

$$;

CREATE OR REPLACE FUNCTION internal_matrix_stats(index regclass, fields text[], query zdbquery) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_matrix_stats';
CREATE OR REPLACE FUNCTION matrix_stats(index regclass, fields text[], query zdbquery) RETURNS TABLE (name text, count bigint, mean numeric, variance numeric, skewness numeric, kurtosis numeric, covariance json, correlation json) STABLE LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_matrix_stats(index, fields, query)::jsonb;
BEGIN
    RETURN QUERY
        SELECT
            field->>'name',
            (field->>'count')::bigint,
            (field->>'mean')::numeric,
            (field->>'variance')::numeric,
            (field->>'skewness')::numeric,
            (field->>'kurtosis')::numeric,
            jsonb_pretty(field->'covariance')::json,
            jsonb_pretty(field->'correlation')::json
          FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'fields') field;
END;
$$;

CREATE OR REPLACE FUNCTION internal_top_hits(index regclass, fields text[], query zdbquery, size int) RETURNS json STABLE STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'zdb_internal_top_hits';
CREATE OR REPLACE FUNCTION top_hits(index regclass, fields text[], query zdbquery, size int) RETURNS TABLE (ctid tid, score float4, source json) STABLE LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_top_hits(index, fields, query, size)::jsonb;
BEGIN
    RETURN QUERY
        SELECT zdb.ctid((hit->>'_id')::bigint),
               (hit->>'_score')::float4,
               jsonb_pretty(hit->'_source')::json
          FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'hits'->'hits') hit;
END;
$$;

CREATE OR REPLACE FUNCTION top_hits_with_id(index regclass, fields text[], query zdbquery, size int) RETURNS TABLE (_id text, score float4, source json) STABLE LANGUAGE plpgsql AS $$
DECLARE
    response jsonb := zdb.internal_top_hits(index, fields, query, size)::jsonb;
BEGIN
    RETURN QUERY
        SELECT hit->>'_id',
               (hit->>'_score')::float4,
               jsonb_pretty(hit->'_source')::json
          FROM jsonb_array_elements(response->'aggregations'->'the_agg'->'hits'->'hits') hit;
END;
$$;
--
-- analyzer api support
--
CREATE OR REPLACE FUNCTION analyze_text(index regclass, analyzer text, text text) RETURNS TABLE (type text, token text, "position" int, start_offset int, end_offset int) PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT tokens->>'type',
           tokens->>'token',
           (tokens->>'position')::int,
           (tokens->>'start_offset')::int,
           (tokens->>'end_offset')::int
      FROM jsonb_array_elements((zdb.request(index, '/_analyze', 'GET', json_build_object('analyzer', analyzer, 'text', text)::text)::jsonb)->'tokens') tokens;
$$;
CREATE OR REPLACE FUNCTION analyze_custom(index regclass, text text DEFAULT NULL, tokenizer text DEFAULT NULL, normalizer text DEFAULT NULL, filter text[] DEFAULT NULL, char_filter text[] DEFAULT NULL) RETURNS TABLE (type text, token text, "position" int, start_offset int, end_offset int) PARALLEL SAFE IMMUTABLE LANGUAGE sql AS $$
    SELECT tokens->>'type',
           tokens->>'token',
           (tokens->>'position')::int,
           (tokens->>'start_offset')::int,
           (tokens->>'end_offset')::int
      FROM jsonb_array_elements((zdb.request(index, '_analyze', 'GET', json_strip_nulls(json_build_object('tokenizer', tokenizer, 'normalizer', normalizer, 'text', text, 'filter', filter, 'char_filter', char_filter))::text)::jsonb)->'tokens') tokens;
$$;
CREATE OR REPLACE FUNCTION analyze_with_field(index regclass, field text, text text) RETURNS TABLE (type text, token text, "position" int, start_offset int, end_offset int) PARALLEL SAFE IMMUTABLE STRICT LANGUAGE sql AS $$
    SELECT tokens->>'type',
           tokens->>'token',
           (tokens->>'position')::int,
           (tokens->>'start_offset')::int,
           (tokens->>'end_offset')::int
      FROM jsonb_array_elements((zdb.request(index, '_analyze', 'GET', json_build_object('field', field, 'text', text)::text)::jsonb)->'tokens') tokens;
$$;

--
-- _cat/ API support
--
CREATE OR REPLACE FUNCTION cat_request(endpoint TEXT) RETURNS TABLE(url TEXT, response JSONB) PARALLEL SAFE IMMUTABLE STRICT LANGUAGE SQL AS $$
    WITH clusters AS (SELECT
                        zdb.index_url(idx) url,
                        idx
                      FROM (SELECT DISTINCT ON (zdb.index_url(oid::regclass)) oid::regclass idx
                            FROM pg_class
                            WHERE relam = (SELECT oid
                                           FROM pg_am
                                           WHERE amname = 'zombodb')) x)
    SELECT
      url,
      jsonb_array_elements(zdb.request(idx, '/_cat/' || $1 || '?h=*&format=json&time=ms&bytes=b&size=k')::jsonb)
    FROM clusters
$$;

CREATE OR REPLACE VIEW cat_aliases AS
    SELECT
        url,
        response->>'alias' AS "alias",
        response->>'index' AS "index",
        response->>'filter' AS "filter",
        response->>'routing.index' AS "routing.index",
        response->>'routing.search' AS "routing.search"
     FROM zdb.cat_request('aliases')
    WHERE response->>'index' IN (SELECT index from zdb.all_es_index_names() index);

CREATE OR REPLACE VIEW cat_allocation AS
    SELECT
        url,
        (response->>'shards')::int AS "shards",
        (response->>'disk.indices')::bigint AS "disk.indices",
        (response->>'disk.used')::bigint AS "disk.used",
        (response->>'disk.avail')::bigint AS "disk.avail",
        (response->>'disk.total')::bigint AS "disk.total",
        (response->>'disk.percent')::real AS "disk.percent",
        (response->>'host') AS "host",
        (response->>'ip')::inet AS "ip",
        (response->>'node') AS "node"
     FROM zdb.cat_request('allocation');

CREATE OR REPLACE VIEW cat_count AS
    SELECT
        url,
        (response->>'epoch')::bigint AS "epoch",
        (response->>'timestamp')::time AS "timestamp",
        (response->>'count')::bigint AS "count"
     FROM zdb.cat_request('count');

CREATE OR REPLACE VIEW cat_fielddata AS
    SELECT
        url,
        (response->>'id') AS "id",
        (response->>'host') AS "host",
        (response->>'ip')::inet AS "ip",
        (response->>'node') AS "node",
        (response->>'field') AS "field",
        (response->>'size')::bigint AS "size"
     FROM zdb.cat_request('fielddata');

CREATE OR REPLACE VIEW cat_health AS
    SELECT
        url,
        (response->>'epoch')::bigint AS "epoch",
        (response->>'timestamp')::time AS "timestamp",
        (response->>'cluster')::text AS "cluster",
        (response->>'status') AS "status",
        (response->>'node.total')::bigint AS "node.total",
        (response->>'node.data')::bigint AS "node.data",
        (response->>'shards')::int AS "shards",
        (response->>'pri')::int AS "pri",
        (response->>'relo')::int AS "relo",
        (response->>'init')::int AS "init",
        (response->>'unassign')::int AS "unassign",
        (response->>'pending_tasks')::int AS "pending_tasks",
        case when response->>'max_task_wait_time' <> '-' then ((response->>'max_task_wait_time')||'milliseconds')::interval else null end AS "max_task_wait_time",
        (response->>'active_shards_percent') AS "active_shards_percent"
     FROM zdb.cat_request('health');

CREATE OR REPLACE VIEW cat_indices AS
    SELECT
        url,
        (response->>'health') AS "health",
        (response->>'status') AS "status",
        (select array_to_string(array_agg(alias), ',') from zdb.cat_aliases where index = response->>'index') as alias,
        (response->>'index') AS "index",
        (response->>'uuid') AS "uuid",
        (response->>'pri')::int AS "pri",
        (response->>'rep')::int AS "rep",
        (response->>'docs.count')::bigint AS "docs.count",
        (response->>'docs.deleted')::bigint AS "docs.deleted",
        (response->>'store.size')::bigint AS "store.size",
        (response->>'pri.store.size')::bigint AS "pri.store.size"
     FROM zdb.cat_request('indices')
     WHERE response->>'index' IN (SELECT index from zdb.all_es_index_names() index);

CREATE OR REPLACE VIEW cat_master AS
    SELECT
        url,
        (response->>'id') AS "id",
        (response->>'host') AS "host",
        (response->>'ip')::inet AS "ip",
        (response->>'node') AS "node"
     FROM zdb.cat_request('master');

CREATE OR REPLACE VIEW cat_nodeattrs AS
    SELECT
        url,
        (response->>'node') AS "node",
        (response->>'host') AS "host",
        (response->>'ip')::inet AS "ip",
        (response->>'attr') AS "attr",
        (response->>'value') AS "value"
     FROM zdb.cat_request('nodeattrs');

CREATE OR REPLACE VIEW cat_nodes AS
    SELECT
        url,
        (response->>'id')::text AS "id",
        (response->>'pid')::int AS "pid",
        (response->>'ip')::inet AS "ip",
        (response->>'port')::int AS "port",
        (response->>'http_address')::text AS "http_address",
        (response->>'version')::text AS "version",
        (response->>'build')::text AS "build",
        (response->>'jdk')::text AS "jdk",

        (response->>'disk.total')::text AS "disk.total",
        (response->>'disk.used')::text AS "disk.used",
        (response->>'disk.avail')::text AS "disk.avail",
        (response->>'disk.used_percent')::real AS "disk.used_percent",

        (response->>'heap.current')::text AS "heap.current",
        (response->>'heap.percent')::real AS "heap.percent",
        (response->>'heap.max')::text AS "heap.max",

        (response->>'ram.current')::text AS "ram.current",
        (response->>'ram.percent')::text AS "ram.percent",
        (response->>'ram.max')::text AS "ram.max",

        (response->>'file_desc.current')::int AS "file_desc.current",
        (response->>'file_desc.percent')::real AS "file_desc.percent",
        (response->>'file_desc.max')::int AS "file_desc.max",

        (response->>'cpu')::real AS "cpu",
        (response->>'load.1m')::real AS "load.1m",
        (response->>'load.5m')::real AS "load.5m",
        (response->>'load.15m')::real AS "load.15m",
        (response->>'uptime')::text AS "uptime",

        (response->>'node.role')::text AS "node.role",
        (response->>'master') = '*' AS "master",
        (response->>'name')::text AS "name",
        (response->>'completion.size')::text AS "completion.size",

        (response->>'fielddata.memory_size')::text AS "fielddata.memory_size",
        (response->>'fielddata.evictions')::int AS "fielddata.evictions",

        (response->>'query_cache.memory.size')::text AS "query_cache.memory.size",
        (response->>'query_cache.evictions')::int AS "query_cache.evictions",

        (response->>'request_cache.memory_size')::text AS "request_cache.memory_size",
        (response->>'request_cache.evictions')::int AS "request_cache.evictions",
        (response->>'request_cache.hit_count')::int AS "request_cache.hit_count",
        (response->>'request_cache.miss_count')::int AS "request_cache.miss_count",

        (response->>'flush.total')::int AS "flush.total",
        ((response->>'flush.total_time')::text||' milliseconds')::interval AS "flush.total_time",

        (response->>'get.current')::int AS "get.current",
        ((response->>'get.time')::text::text||' milliseconds')::interval AS "get.time",
        (response->>'get.total')::bigint AS "get.total",
        ((response->>'get.exists_time')::text||' milliseconds')::interval AS "get.exists_time",
        (response->>'get.exists_total')::bigint AS "get.exists_total",
        ((response->>'get.missing_time')::text||' milliseconds')::interval AS "get.missing_time",
        (response->>'get.missing_total')::bigint AS "get.missing_total",

        (response->>'indexing.delete_current')::bigint AS "indexing.delete_current",
        ((response->>'indexing.delete_time')::text||' milliseconds')::interval AS "indexing.delete_time",
        (response->>'indexing.delete_total')::bigint AS "indexing.delete_total",
        (response->>'indexing.index_current')::bigint AS "indexing.index_current",
        ((response->>'indexing.index_time')::text||' milliseconds')::interval AS "indexing.index_time",
        (response->>'indexing.index_total')::bigint AS "indexing.index_total",
        (response->>'indexing.index_failed')::bigint AS "indexing.index_failed",

        (response->>'merges.current')::bigint AS "merges.current",
        (response->>'merges.current.docs')::bigint AS "merges.current.docs",
        (response->>'merges.current.size')::text AS "merges.current.size",
        (response->>'merges.total')::bigint AS "merges.total",
        (response->>'merges.total_docs')::bigint AS "merges.total_docs",
        (response->>'merges.total_size')::text AS "merges.total_size",
        ((response->>'merges.total_time')::text||' milliseconds')::interval AS "merges.total_time",

        (response->>'refresh.total')::bigint AS "refresh.total",
        ((response->>'refresh.time')::text::text||' milliseconds')::interval AS "refresh.time",
        (response->>'refresh.listeners')::text AS "refresh.listeners",

        (response->>'script.compilations')::bigint AS "script.compilations",
        (response->>'script.cache_evictions')::bigint AS "script.cache_evictions",

        (response->>'search.fetch_current')::bigint AS "search.fetch_current",
        ((response->>'search.fetch_time')::text||' milliseconds')::interval AS "search.fetch_time",
        (response->>'search.fetch_total')::bigint AS "search.fetch_total",
        (response->>'search.open_contexts')::bigint AS "search.open_contexts",
        (response->>'search.query_current')::bigint AS "search.query_current",
        ((response->>'search.query_time')::text||' milliseconds')::interval AS "search.query_time",
        (response->>'search.query_total')::text AS "search.query_total",

        (response->>'search.scroll_current')::bigint AS "search.scroll_current",
        ((response->>'search.scroll_time')::bigint/1000 ||' milliseconds')::interval AS "search.scroll_time",
        (response->>'search.scroll_total')::bigint AS "search.scroll_total",

        (response->>'segments.count')::bigint AS "segments.count",
        (response->>'segments.memory')::text AS "segments.memory",
        (response->>'segments.index_writer_memory')::text AS "segments.index_writer_memory",
        (response->>'segments.version_map_memory')::text AS "segments.version_map_memory",
        (response->>'segments.fixed_bitset_memory')::text AS "segments.fixed_bitset_memory",

        (response->>'suggest.current')::bigint AS "suggest.current",
        ((response->>'suggest.time')::text||' milliseconds')::interval AS "suggest.time",
        (response->>'suggest.total')::bigint AS "suggest.total"
     FROM zdb.cat_request('nodes');

CREATE OR REPLACE VIEW cat_pending_tasks AS
    SELECT
        url,
        (response->>'insertOrder')::int AS "insertOrder",
        ((response->>'timeInQueue')||' milliseconds')::interval AS "timeInQueue",
        (response->>'priority') AS "priority",
        (response->>'source') AS "source"
     FROM zdb.cat_request('pending_tasks');

CREATE OR REPLACE VIEW cat_plugins AS
    SELECT
        url,
        (response->>'name') AS "name",
        (response->>'component') AS "component",
        (response->>'version') AS "version",
        (response->>'description') AS "description"
     FROM zdb.cat_request('plugins');

CREATE OR REPLACE VIEW cat_thread_pool AS
    SELECT
        url,
        (response->>'ip')::inet AS "ip",
        (response->>'max')::int AS "max",
        (response->>'min')::int AS "min",
        (response->>'pid')::int AS "pid",
        (response->>'host')::text AS "host",
        (response->>'name')::text AS "name",
        (response->>'port')::int AS "port",
        (response->>'size')::int AS "size",
        (response->>'type')::text AS "type",
        (response->>'queue')::int AS "queue",
        (response->>'active')::int AS "active",
        (response->>'largest')::int AS "largest",
        (response->>'node_id')::text AS "node_id",
        (response->>'rejected')::int AS "rejected",
        (response->>'completed')::bigint AS "completed",
        (response->>'node_name')::text AS "node_name",
        (response->>'keep_alive')::text AS "keep_alive",
        (response->>'queue_size')::int AS "queue_size",
        (response->>'ephemeral_node_id')::text AS "ephemeral_node_id"
     FROM zdb.cat_request('thread_pool');

CREATE OR REPLACE VIEW cat_shards AS
    SELECT
        url,
        (response->>'id')::text AS "id",
        (response->>'ip')::inet AS "ip",
        (response->>'docs')::bigint AS "docs",
        (response->>'node')::text AS "node",
        (select array_to_string(array_agg(alias), ',') from zdb.cat_aliases where index = response->>'index') as alias,
        (response->>'index')::text AS "index",
        (response->>'shard')::int AS "shard",
        (response->>'state')::text AS "state",
        (response->>'store')::bigint AS "store",
        (response->>'prirep')::text AS "prirep",
        (response->>'sync_id')::text AS "sync_id",
        (response->>'completion.size')::bigint AS "completion.size",
        (response->>'fielddata.evictions')::int AS "fielddata.evictions",
        (response->>'fielddata.memory_size')::bigint AS "fielddata.memory_size",
        (response->>'flush.total')::bigint AS "flush.total",
        ((response->>'flush.total_time')||'milliseconds')::interval AS "flush.total_time",
        (response->>'get.current')::int AS "get.current",
        ((response->>'get.exists_time')||'milliseconds')::interval AS "get.exists_time",
        (response->>'get.exists_total')::bigint AS "get.exists_total",
        ((response->>'get.missing_time')||'milliseconds')::interval AS "get.missing_time",
        (response->>'get.missing_total')::bigint AS "get.missing_total",
        ((response->>'get.time')||'milliseconds')::interval AS "get.time",
        (response->>'get.total')::bigint AS "get.total",
        (response->>'indexing.delete_current')::int AS "indexing.delete_current",
        ((response->>'indexing.delete_time')||'milliseconds')::interval AS "indexing.delete_time",
        (response->>'indexing.delete_total')::bigint AS "indexing.delete_total",
        (response->>'indexing.index_current')::int AS "indexing.index_current",
        (response->>'indexing.index_failed')::bigint AS "indexing.index_failed",
        ((response->>'indexing.index_time')||'milliseconds')::interval AS "indexing.index_time",
        (response->>'indexing.index_total')::bigint AS "indexing.index_total",
        (response->>'merges.current')::int AS "merges.current",
        (response->>'merges.current_docs')::int AS "merges.current_docs",
        (response->>'merges.current_size')::bigint AS "merges.current_size",
        (response->>'merges.total')::bigint AS "merges.total",
        (response->>'merges.total_docs')::bigint AS "merges.total_docs",
        (response->>'merges.total_size')::bigint AS "merges.total_size",
        ((response->>'merges.total_time')||'milliseconds')::interval AS "merges.total_time",
        (response->>'query_cache.evictions')::int AS "query_cache.evictions",
        (response->>'query_cache.memory_size')::bigint AS "query_cache.memory_size",
        (response->>'recoverysource.type')::text AS "recoverysource.type",
        (response->>'refresh.listeners')::int AS "refresh.listeners",
        ((response->>'refresh.time')||'milliseconds')::interval AS "refresh.time",
        (response->>'refresh.total')::bigint AS "refresh.total",
        (response->>'search.fetch_current')::int AS "search.fetch_current",
        ((response->>'search.fetch_time')||'milliseconds')::interval AS "search.fetch_time",
        (response->>'search.fetch_total')::bigint AS "search.fetch_total",
        (response->>'search.open_contexts')::int AS "search.open_contexts",
        (response->>'search.query_current')::int AS "search.query_current",
        ((response->>'search.query_time')||'milliseconds')::interval AS "search.query_time",
        (response->>'search.query_total')::bigint AS "search.query_total",
        (response->>'search.scroll_current')::int AS "search.scroll_current",
        ((response->>'search.scroll_time')::bigint / 1000 ||'milliseconds')::interval AS "search.scroll_time",
        (response->>'search.scroll_total')::bigint AS "search.scroll_total",
        (response->>'segments.count')::int AS "segments.count",
        (response->>'segments.fixed_bitset_memory')::bigint AS "segments.fixed_bitset_memory",
        (response->>'segments.index_writer_memory')::bigint AS "segments.index_writer_memory",
        (response->>'segments.memory')::bigint AS "segments.memory",
        (response->>'segments.version_map_memory')::bigint AS "segments.version_map_memory",
        (response->>'unassigned.at')::text AS "unassigned.at",
        (response->>'unassigned.details')::text AS "unassigned.details",
        (response->>'unassigned.for')::text AS "unassigned.for",
        (response->>'unassigned.reason')::text AS "unassigned.reason",
        (response->>'warmer.current')::int AS "warmer.current",
        (response->>'warmer.total')::bigint AS "warmer.total",
        ((response->>'warmer.total_time')||'milliseconds')::interval AS "warmer.total_time"
     FROM zdb.cat_request('shards')
     WHERE response->>'index' IN (SELECT index from zdb.all_es_index_names() index);

CREATE OR REPLACE VIEW cat_segments AS
    SELECT
        url,
        (response->>'id')::text AS "id",
        (response->>'ip')::inet AS "ip",
        (response->>'size')::bigint AS "size",
        (select array_to_string(array_agg(alias), ',') from zdb.cat_aliases where index = response->>'index') as alias,
        (response->>'index')::text AS "index",
        (response->>'shard')::int AS "shard",
        (response->>'prirep')::text AS "prirep",
        (response->>'segment')::text AS "segment",
        (response->>'version')::text AS "version",
        (response->>'compound')::boolean AS "compound",
        (response->>'committed')::boolean AS "committed",
        (response->>'docs.count')::bigint AS "docs.count",
        (response->>'generation')::int AS "generation",
        (response->>'searchable')::boolean AS "searchable",
        (response->>'size.memory')::bigint AS "size.memory",
        (response->>'docs.deleted')::bigint AS "docs.deleted"
     FROM zdb.cat_request('segments')
     WHERE response->>'index' IN (SELECT index from zdb.all_es_index_names() index);

--
-- PG to ES type mapping support
--

--
-- filter/analyzer/mapping support
--

CREATE TABLE filters (
  name text NOT NULL PRIMARY KEY,
  definition jsonb NOT NULL,
  is_default boolean DEFAULT false NOT NULL
);

CREATE TABLE char_filters (
  name text NOT NULL PRIMARY KEY,
  definition jsonb NOT NULL,
  is_default boolean DEFAULT false NOT NULL
);

CREATE TABLE analyzers (
  name text NOT NULL PRIMARY KEY,
  definition jsonb NOT NULL,
  is_default boolean DEFAULT false NOT NULL
);

CREATE TABLE normalizers (
  name text NOT NULL PRIMARY KEY,
  definition jsonb NOT NULL,
  is_default boolean DEFAULT false NOT NULL
);

CREATE TABLE mappings (
  table_name regclass NOT NULL,
  field_name text NOT NULL,
  definition jsonb NOT NULL,
  es_only boolean NOT NULL DEFAULT false,
  PRIMARY KEY (table_name, field_name)
);

CREATE TABLE type_mappings (
    type_name regtype NOT NULL PRIMARY KEY,
    definition jsonb NOT NULL,
    is_default boolean DEFAULT false NOT NULL
);

CREATE TABLE tokenizers (
  name text NOT NULL PRIMARY KEY,
  definition jsonb NOT NULL
);

SELECT pg_catalog.pg_extension_config_dump('filters', 'WHERE NOT is_default');
SELECT pg_catalog.pg_extension_config_dump('char_filters', 'WHERE NOT is_default');
SELECT pg_catalog.pg_extension_config_dump('analyzers', 'WHERE NOT is_default');
SELECT pg_catalog.pg_extension_config_dump('normalizers', 'WHERE NOT is_default');
SELECT pg_catalog.pg_extension_config_dump('mappings', '');
SELECT pg_catalog.pg_extension_config_dump('tokenizers', '');
SELECT pg_catalog.pg_extension_config_dump('type_mappings', 'WHERE NOT is_default');

CREATE OR REPLACE FUNCTION define_filter(name text, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.filters WHERE name = $1;
  INSERT INTO zdb.filters(name, definition) VALUES ($1, $2);
$$;

CREATE OR REPLACE FUNCTION define_char_filter(name text, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.char_filters WHERE name = $1;
  INSERT INTO zdb.char_filters(name, definition) VALUES ($1, $2);
$$;

CREATE OR REPLACE FUNCTION define_analyzer(name text, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.analyzers WHERE name = $1;
  INSERT INTO zdb.analyzers(name, definition) VALUES ($1, $2);
$$;

CREATE OR REPLACE FUNCTION define_normalizer(name text, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.normalizers WHERE name = $1;
  INSERT INTO zdb.normalizers(name, definition) VALUES ($1, $2);
$$;

CREATE OR REPLACE FUNCTION define_field_mapping(table_name regclass, field_name text, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.mappings WHERE table_name = $1 AND field_name = $2;
  INSERT INTO zdb.mappings(table_name, field_name, definition) VALUES ($1, $2, $3);
$$;

CREATE OR REPLACE FUNCTION define_es_only_field(table_name regclass, field_name text, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.mappings WHERE table_name = $1 AND field_name = $2;
  INSERT INTO zdb.mappings(table_name, field_name, definition, es_only) VALUES ($1, $2, $3, true);
$$;

CREATE OR REPLACE FUNCTION define_type_mapping(type_name regtype, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.type_mappings WHERE type_name = $1;
  INSERT INTO zdb.type_mappings(type_name, definition) VALUES ($1, $2);
$$;

CREATE OR REPLACE FUNCTION define_tokenizer(name text, definition json) RETURNS void LANGUAGE sql VOLATILE STRICT AS $$
  DELETE FROM zdb.tokenizers WHERE name = $1;
  INSERT INTO zdb.tokenizers(name, definition) VALUES ($1, $2);
$$;

INSERT INTO filters(name, definition, is_default) VALUES (
  'zdb_truncate_to_fit', '{
    "type": "truncate",
    "length": 10922
  }', true);
INSERT INTO filters(name, definition, is_default) VALUES ('shingle_filter', '{
          "type": "shingle",
          "min_shingle_size": 2,
          "max_shingle_size": 2,
          "output_unigrams": true,
          "token_separator": "$"
        }', true);
INSERT INTO filters(name, definition, is_default) VALUES ('shingle_filter_search', '{
          "type": "shingle",
          "min_shingle_size": 2,
          "max_shingle_size": 2,
          "output_unigrams": false,
          "token_separator": "$"
        }', true);

INSERT INTO normalizers(name, definition, is_default) VALUES (
  'lowercase', '{
    "type": "custom",
    "char_filter": [],
    "filter": ["lowercase"]
  }', true);

INSERT INTO analyzers(name, definition, is_default) VALUES (
  'zdb_standard', '{
    "type": "standard",
    "filter": [ "zdb_truncate_to_fit", "lowercase" ]
  }', true);
INSERT INTO analyzers(name, definition, is_default) VALUES (
  'zdb_all_analyzer', '{
    "type": "standard",
    "filter": [ "zdb_truncate_to_fit", "lowercase" ]
  }', true);
INSERT INTO analyzers(name, definition, is_default) VALUES (
  'fulltext_with_shingles', '{
          "type": "custom",
          "tokenizer": "standard",
          "filter": [
            "lowercase",
            "shingle_filter"
          ]
        }', true);
INSERT INTO analyzers(name, definition, is_default) VALUES (
  'fulltext_with_shingles_search', '{
          "type": "custom",
          "tokenizer": "standard",
          "filter": [
            "lowercase",
            "shingle_filter_search"
          ]
        }', true);


CREATE DOMAIN fulltext AS text;
CREATE DOMAIN fulltext_with_shingles AS text;
CREATE DOMAIN zdb_standard AS text;

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'bytea', '{
    "type": "binary"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'boolean', '{
    "type": "boolean"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'smallint', '{
    "type": "short"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'integer', '{
    "type": "integer"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'bigint', '{
    "type": "long"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'real', '{
    "type": "float"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'double precision', '{
    "type": "double"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'character varying', '{
    "type": "keyword",
    "copy_to": "zdb_all",
    "ignore_above": 10922,
    "normalizer": "lowercase"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'text', '{
    "type": "text",
    "copy_to": "zdb_all",
    "fielddata": true,
    "analyzer": "zdb_standard"
  }', true);

--INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
--  'citext', '{
--    "type": "text",
--    "copy_to": "zdb_all",
--    "fielddata": true,
--    "analyzer": "zdb_standard"
--  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'time without time zone', '{
    "type": "date",
    "copy_to": "zdb_all",
    "format": "HH:mm:ss.SSSSSS"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'time with time zone', '{
    "type": "date",
    "copy_to": "zdb_all",
    "format": "HH:mm:ss.SSSSSSZZ"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'date', '{
    "type": "date",
    "copy_to": "zdb_all"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'timestamp without time zone', '{
    "type": "date",
    "copy_to": "zdb_all"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'timestamp with time zone', '{
    "type": "date",
    "copy_to": "zdb_all"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'json', '{
    "type": "nested",
    "include_in_parent": true
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'jsonb', '{
    "type": "nested",
    "include_in_parent": true
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'inet', '{
    "type": "ip",
    "copy_to": "zdb_all"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'fulltext', '{
    "type": "text",
    "copy_to": "zdb_all",
    "analyzer": "zdb_standard"
  }', true);

INSERT INTO type_mappings(type_name, definition, is_default) VALUES (
  'fulltext_with_shingles', '{
    "type": "text",
    "copy_to": "zdb_all",
    "analyzer": "fulltext_with_shingles",
    "search_analyzer": "fulltext_with_shingles_search"
  }', true);

CREATE DOMAIN arabic AS text;
CREATE DOMAIN armenian AS text;
CREATE DOMAIN basque AS text;
CREATE DOMAIN brazilian AS text;
CREATE DOMAIN bulgarian AS text;
CREATE DOMAIN catalan AS text;
CREATE DOMAIN chinese AS text;
CREATE DOMAIN cjk AS text;
CREATE DOMAIN czech AS text;
CREATE DOMAIN danish AS text;
CREATE DOMAIN dutch AS text;
CREATE DOMAIN english AS text;
CREATE DOMAIN fingerprint AS text;
CREATE DOMAIN finnish AS text;
CREATE DOMAIN french AS text;
CREATE DOMAIN galician AS text;
CREATE DOMAIN german AS text;
CREATE DOMAIN greek AS text;
CREATE DOMAIN hindi AS text;
CREATE DOMAIN hungarian AS text;
CREATE DOMAIN indonesian AS text;
CREATE DOMAIN irish AS text;
CREATE DOMAIN italian AS text;
CREATE DOMAIN keyword AS character varying;
CREATE DOMAIN latvian AS text;
CREATE DOMAIN norwegian AS text;
CREATE DOMAIN persian AS text;
CREATE DOMAIN portuguese AS text;
CREATE DOMAIN romanian AS text;
CREATE DOMAIN russian AS text;
CREATE DOMAIN sorani AS text;
CREATE DOMAIN spanish AS text;
CREATE DOMAIN simple AS text;
CREATE DOMAIN standard AS text;
CREATE DOMAIN swedish AS text;
CREATE DOMAIN turkish AS text;
CREATE DOMAIN thai AS text;
CREATE DOMAIN whitespace AS text;

GRANT ALL ON analyzers TO PUBLIC;
GRANT ALL ON char_filters TO PUBLIC;
GRANT ALL ON filters TO PUBLIC;
GRANT ALL ON mappings TO PUBLIC;
GRANT ALL ON tokenizers TO PUBLIC;
GRANT ALL ON type_mappings TO PUBLIC;
GRANT ALL ON normalizers TO PUBLIC;
CREATE OR REPLACE FUNCTION llapi_direct_insert(index_name regclass, data json) RETURNS void LANGUAGE c AS 'MODULE_PATHNAME', 'llapi_direct_insert';
CREATE OR REPLACE FUNCTION llapi_direct_delete(index_name regclass, _id text) RETURNS void LANGUAGE c AS 'MODULE_PATHNAME', 'llapi_direct_delete';
--
-- a view to get quick stats about all indexes
--
CREATE OR REPLACE VIEW index_stats AS
  WITH stats AS (
      SELECT
        indrelid :: REGCLASS                                                                 table_name,
        indexrelid::regclass                                                                 ,
        zdb.index_name(indexrelid)                                                          index_name,
        zdb.index_url(indexrelid)                                                           url,
        zdb.request(indexrelid, '_stats', 'GET')::json                                      stats,
        zdb.request(indexrelid, '_settings', 'GET')::json                                   settings
      FROM pg_index, pg_class
      where pg_class.oid = pg_index.indexrelid and relam = (select oid from pg_am where amname = 'zombodb')
  )
  SELECT
    (select array_to_string(array_agg(alias), ',') from zdb.cat_aliases where index = index_name) as alias,
    index_name,
    url,
    table_name,
    stats -> '_all' -> 'primaries' -> 'docs' -> 'count'                                     AS es_docs,
    pg_size_pretty((stats -> '_all' -> 'primaries' -> 'store' ->> 'size_in_bytes') :: INT8) AS es_size,
    (stats -> '_all' -> 'primaries' -> 'store' ->> 'size_in_bytes') :: INT8                 AS es_size_bytes,
    (SELECT reltuples::int8 FROM pg_class WHERE oid = table_name)                           AS pg_docs_estimate,
    pg_size_pretty(pg_total_relation_size(table_name))                                      AS pg_size,
    pg_total_relation_size(table_name)                                                      AS pg_size_bytes,
    stats -> '_shards' -> 'total'                                                           AS shards,
    settings -> index_name -> 'settings' -> 'index' ->> 'number_of_replicas'                AS replicas,
    (zdb.request(indexrelid, 'doc/_count', 'GET') :: JSON) -> 'count'                      AS doc_count,
    coalesce(json_array_length((zdb.request(indexrelid, 'doc/zdb_aborted_xids', 'GET') :: JSON) -> '_source'->'zdb_aborted_xids'), 0) AS aborted_xids
  FROM stats;
